﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using xamarinwebapi.Models;

namespace xamarinwebapi.Controllers
{
    public class MasterController : ApiController
    {
        //public IEnumerable<Employee> GetEmployees()
        //{
        //    List<Employee> employeData = new List<Employee>();
        //    employeData.Add(new Employee { Id = 1, Name = "Krishhna kumar", Addresss = "mgr nagar", PhoneNumber = "99999999999" });

        //    return employeData;
        //}
        SqlConnection conn;
        private void connection()
        {
            string conString = ConfigurationManager.ConnectionStrings["getConnection"].ToString();
            conn = new SqlConnection(conString);
        }

        public IEnumerable<Employee> GetEmployees()
        {
            List<Employee> employeeData = new List<Employee>();

            connection();
            SqlCommand cmd = new SqlCommand("spGetEmployee", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Employee employee = new Employee();
                employee.Id = Convert.ToInt32(reader["Id"]);
                employee.Name = reader["Name"].ToString();
                employee.Addresss = reader["Address"].ToString();
                employee.PhoneNumber = reader["PhoneNumbaer"].ToString();

                employeeData.Add(employee);
            }
            conn.Close();
            

           
            return employeeData;
        }


        public Response SaveEmployee(Employee employee)
        {
            Response response = new Response();
            try
            {
                if (string.IsNullOrEmpty(employee.Name))
                {
     
                }
                else if (string.IsNullOrEmpty(employee.Addresss))
                {

                }
                else if (string.IsNullOrEmpty(employee.PhoneNumber))
                {
               }
                else
                {
                    connection();
                    SqlCommand com = new SqlCommand("spAddEmployee", conn);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@Name", employee.Name);
                    com.Parameters.AddWithValue("@Address", employee.Addresss);
                    com.Parameters.AddWithValue("@PhoneNumbaer", employee.PhoneNumber);

                    conn.Open();
                    int i = com.ExecuteNonQuery();
                    conn.Close();
                    if (i >= 1)
                    {
                       
                    }
                    else
                    {
                       
                    }
                }
            }
            catch (Exception ex)
            {
                
            }
            return response;
        }



        public Response DeleteEmployee(int EmployeeId)
        {
            Response response = new Response();
            try
            {
                connection();
                SqlCommand com = new SqlCommand("spDeleteEmployee", conn);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@EmployeeId", EmployeeId);
                conn.Open();
                int i = com.ExecuteNonQuery();
                conn.Close();
                if (i >= 1)
                {
                    
                }
                else
                {
                   
                }
            }
            catch (Exception ex)
            {
                
            }
            return response;
        }

        public Response updateEmployee(Employee employee)
        {
            Response response = new Response();
            try
            {
                if (string.IsNullOrEmpty(employee.Name))
                {

                }
                else if (string.IsNullOrEmpty(employee.Addresss))
                {

                }
                else if (string.IsNullOrEmpty(employee.PhoneNumber))
                {
                }
                else
                {
                    connection();
                    SqlCommand com = new SqlCommand("spupdateEmployee", conn);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@id", employee.Id);
                    com.Parameters.AddWithValue("@Name", employee.Name);
                    com.Parameters.AddWithValue("@Address", employee.Addresss);
                    com.Parameters.AddWithValue("@PhoneNumbaer", employee.PhoneNumber);

                    conn.Open();
                    int i = com.ExecuteNonQuery();
                    conn.Close();
                    if (i >= 1)
                    {

                    }
                    else
                    {

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return response;
        }

    }
}
