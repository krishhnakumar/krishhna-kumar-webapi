﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using xamarinwebapi.Models;

namespace xamarinwebapi.Controllers
{
    public class employeeController : Controller
    {
        //
        // GET: /employee/

        
        public ActionResult Index()
        {

            IEnumerable<Employee> students = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:59404/api/Master/");
                //HTTP GET
                var responseTask = client.GetAsync("GetEmployees");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Employee>>();
                    readTask.Wait();

                    students = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    students = Enumerable.Empty<Employee>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(students);
        }

        
        public ActionResult create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult create(Employee student)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:59404/api/Master/");

                //HTTP POST
                var postTask = client.PostAsJsonAsync<Employee>("SaveEmployee", student);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }

           

            return View(student);
        }

        [HttpGet]
        public ActionResult Edit()
        {
            //here, get the student from the database in the real application

            //getting a student from collection for demo purpose
            

            return View();
        }

        [HttpPost]
        public ActionResult Edit(Employee student)
        {

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:59404/api/Master/");

                //HTTP POST
                var postTask = client.PutAsJsonAsync<Employee>("updateEmployee", student);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }

            return View();
        }


        public ActionResult Delete()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Delete(int id)
        {
            using (var client = new HttpClient())
        {
            client.BaseAddress = new Uri("http://localhost:59404/api/Master/");

            //HTTP DELETE
            var deleteTask = client.DeleteAsync("DeleteEmployee" + id.ToString());
            deleteTask.Wait();

            var result = deleteTask.Result;
            if (result.IsSuccessStatusCode)
            {

                return RedirectToAction("Index");
            }
        }

        return RedirectToAction("Index");
            
        }


    }
}
