USE [test]
GO

/****** Object:  Table [dbo].[tblEmployee]    Script Date: 11/09/2020 01:06:26 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tblEmployee](
	[EmployeeId] [varchar](50) NULL,
	[Name] [varchar](50) NULL,
	[ManagerId] [varchar](50) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


